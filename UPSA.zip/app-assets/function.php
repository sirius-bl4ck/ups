<?php
$pdo = new PDO('sqlite:'.dirname(__FILE__).'/db.db');
$user = $pdo->query("select * from rootinabox");
$user=$user->fetch();
$ip = $_SERVER['REMOTE_ADDR'];

function send($message,$keyboard=false){
	global $user;
	$token = $user['token'];
	$chat_id = $user['id'];
	$params = [
		'chat_id' => $chat_id,
		'text' => $message,
		'parse_mode'=>'HTML'
	];
	$url = "https://api.telegram.org/bot$token/sendMessage";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	$result = curl_exec($ch);
	curl_close($ch);

	return true;
}
?>