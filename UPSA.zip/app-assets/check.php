<?php
require_once('function.php');
echo $user['key'];
?>